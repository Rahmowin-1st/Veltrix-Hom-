package com.veltrix.calculator.app.frontend.glass

import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import android.view.View
import kotlin.math.max

/** Shared optical renderer used by all high-value Veltrix glass controls. */
class GlassMaterialRenderer(private val owner: View) {

    enum class Variant {
        REGULAR_CLEAR,
        HIGH_CLARITY,
        TINTED_ACTION,
        THICK_EXPANDED,
        LIGHTWEIGHT,
    }

    private val opticalPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fallbackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fallbackRect = RectF()

    private var runtimeShader: RuntimeShader? = null
    private var bitmapShader: BitmapShader? = null
    private var boundGeneration = Long.MIN_VALUE
    private var boundBitmapId = 0

    private val hostLocation = IntArray(2)
    private val ownerLocation = IntArray(2)
    private var cachedHost: GlassSceneHost? = null

    private val shaderSource = """
        uniform shader scene;
        uniform float2 size;
        uniform float2 sceneOrigin;
        uniform float radius;
        uniform float press;
        uniform float2 touch;
        uniform float4 tint;
        uniform float tintStrength;
        uniform float thickness;
        uniform float clarity;

        float sdRoundRect(float2 p, float2 b, float r) {
            float2 q = abs(p) - b + r;
            return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
        }

        half4 main(float2 fragCoord) {
            float2 center = size * 0.5;
            float2 p = fragCoord - center;
            float2 halfSize = max(center - float2(1.0), float2(1.0));
            float d = sdRoundRect(p, halfSize, radius);
            float edgeBand = max(3.0, 5.0 + thickness * 5.0);
            float edge = smoothstep(-edgeBand, 0.0, d);
            float2 n = normalize(p / max(halfSize, float2(1.0)) + float2(0.0001));

            float2 uv = sceneOrigin + fragCoord;
            float magnify = (1.0 - edge) * (0.008 + thickness * 0.010);
            float2 centerWarp = -p * magnify;
            float2 edgeWarp = n * edge * edge * (2.4 + 5.6 * thickness + 2.8 * press);

            float2 touchP = touch - center;
            float maxDim = max(size.x, size.y);
            float td = length(p - touchP) / max(maxDim, 1.0);
            float touchEnergy = exp(-td * td * 12.0) * press;
            float2 touchDir = normalize((p - touchP) + float2(0.001));
            float2 touchWarp = touchDir * touchEnergy * (1.2 + thickness * 2.5);

            float2 sampleCoord = uv + centerWarp + edgeWarp + touchWarp;
            half4 base = scene.eval(sampleCoord);

            float chroma = 0.30 + 0.62 * thickness;
            half4 cR = scene.eval(sampleCoord + n * chroma);
            half4 cB = scene.eval(sampleCoord - n * chroma);
            half3 transmitted = half3(cR.r, base.g, cB.b);

            half luminance = dot(transmitted, half3(0.2126, 0.7152, 0.0722));
            half3 adaptiveTint = half3(tint.rgb) * half(0.82 + 0.25 * float(luminance));
            half3 color = mix(transmitted, adaptiveTint, half(tintStrength));

            float scatter = 0.025 + (1.0 - clarity) * 0.09 + press * 0.018;
            color = mix(color, half3(1.0), half(scatter));

            float2 lightDir = normalize(float2(-0.58, -0.82));
            float hi = edge * max(0.0, dot(n, lightDir));
            float low = edge * max(0.0, dot(n, -lightDir));
            float touchLight = touchEnergy * (0.08 + edge * 0.18);
            color += half3(hi * (0.20 + thickness * 0.18) + touchLight);
            color -= half3(low * (0.045 + thickness * 0.07));

            float alpha = 0.82 + 0.12 * clarity + 0.035 * thickness;
            return half4(clamp(color, half3(0.0), half3(1.0)), half(clamp(alpha, 0.0, 1.0)));
        }
    """.trimIndent()

    fun draw(
        canvas: Canvas,
        bounds: RectF,
        radiusPx: Float,
        variant: Variant,
        tintColor: Int,
        press: Float,
        touchX: Float,
        touchY: Float,
        reducedTransparency: Boolean = false,
    ) {
        val host = findHost() ?: run {
            drawFallback(canvas, bounds, radiusPx, variant, tintColor, press, reducedTransparency)
            return
        }
        if (host.isCapturingScene) return

        if (Build.VERSION.SDK_INT >= 33 && host.sceneSnapshot != null && !reducedTransparency) {
            val bitmap = host.sceneSnapshot!!
            if (runtimeShader == null) runtimeShader = RuntimeShader(shaderSource)
            if (bitmapShader == null || boundGeneration != host.sceneGeneration || boundBitmapId != System.identityHashCode(bitmap)) {
                bitmapShader = BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                runtimeShader!!.setInputShader("scene", bitmapShader!!)
                boundGeneration = host.sceneGeneration
                boundBitmapId = System.identityHashCode(bitmap)
            }

            host.getLocationInWindow(hostLocation)
            owner.getLocationInWindow(ownerLocation)
            val originX = (ownerLocation[0] - hostLocation[0]).toFloat() + bounds.left
            val originY = (ownerLocation[1] - hostLocation[1]).toFloat() + bounds.top

            val thickness = when (variant) {
                Variant.HIGH_CLARITY -> 0.62f
                Variant.TINTED_ACTION -> 0.88f
                Variant.THICK_EXPANDED -> 1.35f
                Variant.LIGHTWEIGHT -> 0.42f
                Variant.REGULAR_CLEAR -> 0.76f
            }
            val clarity = when (variant) {
                Variant.HIGH_CLARITY -> 0.96f
                Variant.THICK_EXPANDED -> 0.72f
                Variant.LIGHTWEIGHT -> 0.88f
                else -> 0.90f
            }
            val tintStrength = when (variant) {
                Variant.TINTED_ACTION -> 0.27f
                Variant.THICK_EXPANDED -> 0.07f
                Variant.LIGHTWEIGHT -> 0.035f
                else -> 0.045f
            }
            val r = Color.red(tintColor) / 255f
            val g = Color.green(tintColor) / 255f
            val b = Color.blue(tintColor) / 255f
            val shader = runtimeShader!!
            shader.setFloatUniform("size", bounds.width(), bounds.height())
            shader.setFloatUniform("sceneOrigin", originX, originY)
            shader.setFloatUniform("radius", radiusPx)
            shader.setFloatUniform("press", press.coerceIn(0f, 1f))
            shader.setFloatUniform("touch", touchX - bounds.left, touchY - bounds.top)
            shader.setFloatUniform("tint", r, g, b, 1f)
            shader.setFloatUniform("tintStrength", tintStrength)
            shader.setFloatUniform("thickness", thickness)
            shader.setFloatUniform("clarity", clarity)
            opticalPaint.shader = shader
            canvas.drawRoundRect(bounds, radiusPx, radiusPx, opticalPaint)
            opticalPaint.shader = null
            drawOpticalRim(canvas, bounds, radiusPx, press, thickness)
        } else {
            drawFallback(canvas, bounds, radiusPx, variant, tintColor, press, reducedTransparency)
        }
    }

    private fun drawOpticalRim(canvas: Canvas, bounds: RectF, radius: Float, press: Float, thickness: Float) {
        rimPaint.strokeWidth = max(1f, owner.resources.displayMetrics.density * (0.7f + thickness * 0.25f))
        rimPaint.color = Color.argb((82 + press * 38).toInt().coerceIn(0, 140), 255, 255, 255)
        fallbackRect.set(bounds)
        fallbackRect.inset(rimPaint.strokeWidth * 0.55f, rimPaint.strokeWidth * 0.55f)
        canvas.drawRoundRect(fallbackRect, max(0f, radius - rimPaint.strokeWidth), max(0f, radius - rimPaint.strokeWidth), rimPaint)
    }

    private fun drawFallback(
        canvas: Canvas,
        bounds: RectF,
        radiusPx: Float,
        variant: Variant,
        tintColor: Int,
        press: Float,
        reducedTransparency: Boolean,
    ) {
        val baseAlpha = when {
            reducedTransparency -> 238
            variant == Variant.LIGHTWEIGHT -> 188
            variant == Variant.HIGH_CLARITY -> 168
            else -> 198
        }
        val tintMix = if (variant == Variant.TINTED_ACTION) 0.18f else 0.04f
        val rr = (255 * (1f - tintMix) + Color.red(tintColor) * tintMix).toInt()
        val gg = (255 * (1f - tintMix) + Color.green(tintColor) * tintMix).toInt()
        val bb = (255 * (1f - tintMix) + Color.blue(tintColor) * tintMix).toInt()
        fallbackPaint.style = Paint.Style.FILL
        fallbackPaint.color = Color.argb((baseAlpha + press * 10).toInt().coerceAtMost(248), rr, gg, bb)
        canvas.drawRoundRect(bounds, radiusPx, radiusPx, fallbackPaint)
        rimPaint.strokeWidth = owner.resources.displayMetrics.density
        rimPaint.color = Color.argb(if (reducedTransparency) 92 else 118, 255, 255, 255)
        fallbackRect.set(bounds)
        fallbackRect.inset(rimPaint.strokeWidth * 0.5f, rimPaint.strokeWidth * 0.5f)
        canvas.drawRoundRect(fallbackRect, radiusPx, radiusPx, rimPaint)
    }

    private fun findHost(): GlassSceneHost? {
        cachedHost?.let { return it }
        var parent = owner.parent
        while (parent != null) {
            if (parent is GlassSceneHost) {
                cachedHost = parent
                return parent
            }
            parent = parent.parent
        }
        return null
    }
}
