package com.veltrix.calculator.app.frontend.glass

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max

class LiquidSegmentedControl @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    var labels: List<String> = listOf("Standard", "Scientific", "Programmer")
        set(value) { field = value.ifEmpty { listOf("Standard") }; selectedIndex = selectedIndex.coerceIn(0, field.lastIndex); invalidate() }
    var selectedIndex: Int = 0
        private set
    var onSelectionChanged: ((Int) -> Unit)? = null
    var reducedTransparency: Boolean = false

    private val renderer = GlassMaterialRenderer(this)
    private val lens = RectF()
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val normalTypeface = Typeface.create("sans", Typeface.NORMAL)
    private val boldTypeface = Typeface.create("sans", Typeface.BOLD)
    private var dragging = false
    private var lastX = 0f
    private var lastTime = 0L
    private var releaseVelocity = 0f
    private val position = SpringFloat(0f, 420f, 38f) { invalidate() }
    private val activation = SpringFloat(0f, 520f, 44f) { invalidate() }

    init {
        isClickable = true
        isFocusable = true
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        position.snapTo(selectedIndex.toFloat())
    }

    override fun onDraw(canvas: Canvas) {
        val host = findHost()
        if (host?.isCapturingScene == true) return
        if (labels.isEmpty()) return
        val density = resources.displayMetrics.density
        val segment = width.toFloat() / labels.size
        val p = position.value.coerceIn(0f, labels.lastIndex.toFloat())
        val activated = activation.value.coerceIn(0f, 1f)
        val expansion = 5f * density * activated
        val left = p * segment + 2f * density - expansion
        val right = (p + 1f) * segment - 2f * density + expansion
        lens.set(left, 2f * density - expansion * 0.18f, right, height - 2f * density + expansion * 0.18f)
        renderer.draw(
            canvas,
            lens,
            lens.height() * 0.48f,
            GlassMaterialRenderer.Variant.HIGH_CLARITY,
            Color.rgb(242, 178, 72),
            activated,
            lastX,
            height * 0.5f,
            reducedTransparency,
        )

        textPaint.textSize = 14f * density
        labels.forEachIndexed { index, label ->
            val distance = abs(p - index)
            val active = (1f - distance).coerceIn(0f, 1f)
            val gray = (105 - active * 78).toInt().coerceIn(24, 105)
            textPaint.color = Color.rgb(gray, gray, gray)
            textPaint.typeface = if (active > 0.55f) boldTypeface else normalTypeface
            val baseline = height * 0.5f - (textPaint.ascent() + textPaint.descent()) * 0.5f
            canvas.drawText(label, (index + 0.5f) * segment, baseline, textPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val segment = width.toFloat() / max(1, labels.size)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = event.x
                lastTime = event.eventTime
                releaseVelocity = 0f
                activation.animateTo(1f)
                position.snapTo((event.x / segment - 0.5f).coerceIn(0f, labels.lastIndex.toFloat()), position.velocity)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dt = (event.eventTime - lastTime).coerceAtLeast(1L) / 1000f
                releaseVelocity = ((event.x - lastX) / segment) / dt
                lastX = event.x
                lastTime = event.eventTime
                position.snapTo((event.x / segment - 0.5f).coerceIn(0f, labels.lastIndex.toFloat()), releaseVelocity)
                return true
            }
            MotionEvent.ACTION_UP -> {
                val index = (event.x / segment).toInt().coerceIn(0, labels.lastIndex)
                selectedIndex = index
                position.animateTo(index.toFloat(), releaseVelocity)
                activation.animateTo(0f)
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                onSelectionChanged?.invoke(index)
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                position.animateTo(selectedIndex.toFloat(), releaseVelocity)
                activation.animateTo(0f)
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    private fun findHost(): GlassSceneHost? {
        var p = parent
        while (p != null) { if (p is GlassSceneHost) return p; p = p.parent }
        return null
    }
}
