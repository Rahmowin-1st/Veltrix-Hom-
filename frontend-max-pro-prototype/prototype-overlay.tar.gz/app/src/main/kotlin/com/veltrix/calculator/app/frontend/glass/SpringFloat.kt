package com.veltrix.calculator.app.frontend.glass

import android.view.Choreographer
import kotlin.math.abs

/** Small allocation-free, interruptible spring for direct manipulation handoff. */
class SpringFloat(
    initial: Float,
    private val stiffness: Float = 360f,
    private val damping: Float = 34f,
    private val onUpdate: (Float) -> Unit,
) : Choreographer.FrameCallback {
    var value: Float = initial
        private set
    var velocity: Float = 0f
        private set
    private var target = initial
    private var running = false
    private var lastNanos = 0L

    fun snapTo(newValue: Float, newVelocity: Float = 0f) {
        target = newValue
        value = newValue
        velocity = newVelocity
        stop()
        onUpdate(value)
    }

    fun animateTo(newTarget: Float, initialVelocity: Float? = null) {
        target = newTarget
        if (initialVelocity != null) velocity = initialVelocity
        if (!running) {
            running = true
            lastNanos = 0L
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun stop() {
        if (running) Choreographer.getInstance().removeFrameCallback(this)
        running = false
        lastNanos = 0L
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        if (lastNanos == 0L) {
            lastNanos = frameTimeNanos
            Choreographer.getInstance().postFrameCallback(this)
            return
        }
        val dt = ((frameTimeNanos - lastNanos) / 1_000_000_000f).coerceIn(1f / 240f, 1f / 30f)
        lastNanos = frameTimeNanos
        val displacement = value - target
        val acceleration = -stiffness * displacement - damping * velocity
        velocity += acceleration * dt
        value += velocity * dt
        onUpdate(value)
        if (abs(value - target) < 0.0006f && abs(velocity) < 0.004f) {
            value = target
            velocity = 0f
            running = false
            onUpdate(value)
        } else {
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
}
