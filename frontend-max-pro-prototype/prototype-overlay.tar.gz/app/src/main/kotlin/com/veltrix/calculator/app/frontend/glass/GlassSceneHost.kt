package com.veltrix.calculator.app.frontend.glass

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.FrameLayout
import kotlin.math.max

/**
 * A controlled scene host for Veltrix optical controls.
 *
 * The host keeps one reusable snapshot of the real child content layer. Glass views are
 * omitted while that snapshot is recorded, so they can refract the content underneath
 * without recursively sampling themselves. The snapshot is refreshed only when explicitly
 * invalidated or when the host size changes; interaction-only glass animation does not cause
 * a full-scene copy every frame.
 */
class GlassSceneHost @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : FrameLayout(context, attrs) {

    private var sceneBitmap: Bitmap? = null
    private var sceneCanvas: Canvas? = null
    private var dirty = true
    private var generationInternal = 0L
    internal var isCapturingScene: Boolean = false
        private set

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fieldPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var baseGradient: Shader? = null
    private var fieldA: Shader? = null
    private var fieldB: Shader? = null

    val sceneGeneration: Long get() = generationInternal
    val sceneSnapshot: Bitmap? get() = sceneBitmap

    init {
        setWillNotDraw(false)
        clipChildren = false
        clipToPadding = false
    }

    fun invalidateScene() {
        dirty = true
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        sceneBitmap?.recycle()
        sceneBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        sceneCanvas = Canvas(sceneBitmap!!)
        baseGradient = LinearGradient(
            0f,
            0f,
            w.toFloat(),
            h.toFloat(),
            Color.rgb(251, 251, 248),
            Color.rgb(246, 249, 252),
            Shader.TileMode.CLAMP,
        )
        fieldA = RadialGradient(
            w * 0.18f,
            h * 0.20f,
            max(w, h) * 0.64f,
            intArrayOf(Color.rgb(255, 247, 229), Color.argb(0, 255, 247, 229)),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP,
        )
        fieldB = RadialGradient(
            w * 0.86f,
            h * 0.58f,
            max(w, h) * 0.58f,
            intArrayOf(Color.rgb(228, 241, 255), Color.argb(0, 228, 241, 255)),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP,
        )
        dirty = true
    }

    override fun onDraw(canvas: Canvas) {
        drawSceneBase(canvas)
    }

    private fun drawSceneBase(canvas: Canvas) {
        basePaint.shader = baseGradient
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), basePaint)
        fieldPaint.shader = fieldA
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fieldPaint)
        fieldPaint.shader = fieldB
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fieldPaint)
        basePaint.shader = null
        fieldPaint.shader = null
    }

    override fun dispatchDraw(canvas: Canvas) {
        if (dirty && !isCapturingScene && width > 0 && height > 0) {
            updateSceneSnapshot()
        }
        super.dispatchDraw(canvas)
    }

    private fun updateSceneSnapshot() {
        val target = sceneCanvas ?: return
        val bitmap = sceneBitmap ?: return
        isCapturingScene = true
        try {
            bitmap.eraseColor(Color.TRANSPARENT)
            drawSceneBase(target)
            super.dispatchDraw(target)
            generationInternal += 1L
            dirty = false
        } finally {
            isCapturingScene = false
        }
    }
}
