package com.veltrix.calculator.app.frontend.glass

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

class LiquidSlider @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    var value: Float = 0.45f
        private set
    var onValueChanged: ((Float) -> Unit)? = null
    var reducedTransparency: Boolean = false

    private val renderer = GlassMaterialRenderer(this)
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val track = RectF()
    private val lens = RectF()
    private var dragging = false
    private var lastX = 0f
    private var lastTime = 0L
    private var velocityPx = 0f
    private val activation = SpringFloat(0f, 480f, 40f) { invalidate() }
    private val settle = SpringFloat(value, 380f, 34f) { value = it.coerceIn(0f, 1f); invalidate(); onValueChanged?.invoke(value) }

    init { isClickable = true; isFocusable = true }

    override fun onDraw(canvas: Canvas) {
        val host = findHost(); if (host?.isCapturingScene == true) return
        val d = resources.displayMetrics.density
        val left = 18f * d
        val right = width - 18f * d
        val cy = height * 0.5f
        val trackH = 7f * d
        track.set(left, cy - trackH * 0.5f, right, cy + trackH * 0.5f)
        trackPaint.color = Color.argb(62, 50, 54, 58)
        canvas.drawRoundRect(track, trackH, trackH, trackPaint)
        val x = left + value * (right - left)
        trackPaint.color = Color.rgb(221, 157, 51)
        canvas.drawRoundRect(left, track.top, x, track.bottom, trackH, trackH, trackPaint)

        val a = activation.value.coerceIn(0f, 1f)
        val halfW = (12f + 20f * a + (kotlin.math.abs(velocityPx) / max(width, 1) * 14f).coerceAtMost(10f)) * d
        val halfH = (12f + 6f * a) * d
        lens.set(x - halfW, cy - halfH, x + halfW, cy + halfH)
        renderer.draw(canvas, lens, halfH * 0.92f, GlassMaterialRenderer.Variant.HIGH_CLARITY, Color.rgb(236, 171, 62), a, x, cy, reducedTransparency)

        // Optical continuity: filled track appears to enter the active lens.
        if (a > 0.02f) {
            trackPaint.color = Color.argb((220 * a).toInt(), 221, 157, 51)
            canvas.drawRoundRect(x - halfW * 0.78f, cy - 2.6f * d, x + halfW * 0.15f, cy + 2.6f * d, 3f * d, 3f * d, trackPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val d = resources.displayMetrics.density
        val left = 18f * d
        val right = width - 18f * d
        fun valueFor(x: Float) = ((x - left) / max(1f, right - left)).coerceIn(0f, 1f)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true; parent?.requestDisallowInterceptTouchEvent(true)
                lastX = event.x; lastTime = event.eventTime; velocityPx = 0f
                settle.stop(); value = valueFor(event.x); activation.animateTo(1f)
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                onValueChanged?.invoke(value); invalidate(); return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dt = (event.eventTime - lastTime).coerceAtLeast(1L) / 1000f
                velocityPx = (event.x - lastX) / dt
                lastX = event.x; lastTime = event.eventTime
                value = valueFor(event.x); onValueChanged?.invoke(value); invalidate(); return true
            }
            MotionEvent.ACTION_UP -> {
                val normalizedVelocity = velocityPx / max(1f, right - left)
                settle.snapTo(value, normalizedVelocity)
                settle.animateTo(value, normalizedVelocity)
                activation.animateTo(0f)
                dragging = false; parent?.requestDisallowInterceptTouchEvent(false); performClick(); return true
            }
            MotionEvent.ACTION_CANCEL -> {
                activation.animateTo(0f); dragging = false; parent?.requestDisallowInterceptTouchEvent(false); return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    private fun findHost(): GlassSceneHost? {
        var p = parent
        while (p != null) { if (p is GlassSceneHost) return p; p = p.parent }
        return null
    }
}
