package com.veltrix.calculator.app.frontend.prototype

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.veltrix.calculator.app.frontend.glass.GlassMaterialRenderer
import com.veltrix.calculator.app.frontend.glass.GlassSceneHost
import com.veltrix.calculator.app.frontend.glass.LiquidGlassButton
import com.veltrix.calculator.app.frontend.glass.LiquidSegmentedControl
import com.veltrix.calculator.app.frontend.glass.LiquidSlider

/** Internal visual/performance gate surface. Not a shipping navigation destination. */
class GlassPrototypeActivity : Activity() {
    private fun dp(v: Float) = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(249, 249, 246)
        window.navigationBarColor = Color.rgb(249, 249, 246)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        setContentView(buildLab())
    }

    private fun buildLab(): View {
        val host = GlassSceneHost(this).apply {
            setPadding(dp(20f), dp(16f), dp(20f), dp(28f))
            contentDescription = "Veltrix Liquid Glass Prototype Lab"
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        host.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        content.addView(TextView(this).apply {
            text = "Veltrix Optical Material Lab"
            setTextColor(Color.rgb(27, 29, 31)); textSize = 27f; setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(12f), 0, dp(4f))
        })
        content.addView(TextView(this).apply {
            text = "Controlled real-content sampling • API 33+ AGSL path"
            setTextColor(Color.rgb(91, 94, 98)); textSize = 13f; setPadding(0, 0, 0, dp(18f))
        })

        content.addView(section("1  Clear back control", clearBackDemo()))
        content.addView(section("2  Two-icon glass pill", twoIconDemo()))
        content.addView(section("3  Tinted primary action", tintedDemo()))
        content.addView(section("4  Thick confirmation surface", dialogDemo()))
        content.addView(section("5  Contextual menu growth", menuDemo(host)))
        content.addView(section("6  Continuous segmented lens", segmentedDemo()))
        content.addView(section("7  Finger-following slider lens", sliderDemo()))
        content.addView(section("8  Calculator hierarchy", keypadDemo()))
        return host
    }

    private fun section(title: String, demo: View): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, dp(10f), 0, dp(16f))
        addView(TextView(this@GlassPrototypeActivity).apply {
            text = title; textSize = 14f; setTextColor(Color.rgb(88, 90, 93)); setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(2f), 0, 0, dp(8f))
        })
        addView(demo)
    }

    private fun opticalBackdrop(heightDp: Float, phrase: String): FrameLayout = FrameLayout(this).apply {
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp))
        addView(TextView(this@GlassPrototypeActivity).apply {
            text = phrase
            textSize = 24f
            setTextColor(Color.rgb(105, 133, 164))
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun clearBackDemo(): View = opticalBackdrop(92f, "LIGHT  /  CONTENT  /  2026").apply {
        addView(LiquidGlassButton(this@GlassPrototypeActivity).apply {
            glyph = LiquidGlassButton.Glyph.BACK
            variant = GlassMaterialRenderer.Variant.HIGH_CLARITY
        }, FrameLayout.LayoutParams(dp(58f), dp(58f), Gravity.CENTER))
    }

    private fun twoIconDemo(): View = opticalBackdrop(92f, "VECTOR  ×  OPTICS  ×  DEPTH").apply {
        val pill = LinearLayout(this@GlassPrototypeActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(LiquidGlassButton(context).apply { glyph = LiquidGlassButton.Glyph.GRID; variant = GlassMaterialRenderer.Variant.REGULAR_CLEAR }, LinearLayout.LayoutParams(dp(66f), dp(58f)))
            addView(LiquidGlassButton(context).apply { glyph = LiquidGlassButton.Glyph.LIBRARY; variant = GlassMaterialRenderer.Variant.REGULAR_CLEAR }, LinearLayout.LayoutParams(dp(66f), dp(58f)))
        }
        addView(pill, FrameLayout.LayoutParams(dp(132f), dp(58f), Gravity.CENTER))
    }

    private fun tintedDemo(): View = opticalBackdrop(92f, "48 × 25 = 1200").apply {
        addView(LiquidGlassButton(this@GlassPrototypeActivity).apply {
            label = "="
            variant = GlassMaterialRenderer.Variant.TINTED_ACTION
            tintColor = Color.rgb(226, 158, 42)
        }, FrameLayout.LayoutParams(dp(132f), dp(58f), Gravity.CENTER))
    }

    private fun dialogDemo(): View = opticalBackdrop(138f, "RESULT  12.4875     HISTORY  08:42").apply {
        addView(LiquidGlassButton(this@GlassPrototypeActivity).apply {
            label = "Confirm clear history"
            variant = GlassMaterialRenderer.Variant.THICK_EXPANDED
        }, FrameLayout.LayoutParams(dp(270f), dp(76f), Gravity.CENTER))
    }

    private fun menuDemo(host: GlassSceneHost): View = opticalBackdrop(148f, "MENU  •  grows from source  •  continuity").apply {
        val button = LiquidGlassButton(this@GlassPrototypeActivity).apply {
            glyph = LiquidGlassButton.Glyph.BRAIN
            variant = GlassMaterialRenderer.Variant.HIGH_CLARITY
        }
        val menu = LiquidGlassButton(this@GlassPrototypeActivity).apply {
            label = "Calculator    Library    Graphs"
            variant = GlassMaterialRenderer.Variant.THICK_EXPANDED
            alpha = 0f; scaleX = 0.22f; scaleY = 0.42f; pivotX = 0f; pivotY = 0f; visibility = View.INVISIBLE
        }
        addView(button, FrameLayout.LayoutParams(dp(58f), dp(58f), Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(26f) })
        addView(menu, FrameLayout.LayoutParams(dp(292f), dp(72f), Gravity.START or Gravity.BOTTOM).apply { leftMargin = dp(26f); bottomMargin = dp(4f) })
        button.setOnClickListener {
            if (menu.visibility != View.VISIBLE) {
                menu.visibility = View.VISIBLE
                menu.animate().cancel(); menu.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220L).start()
            } else {
                menu.animate().cancel(); menu.animate().alpha(0f).scaleX(0.22f).scaleY(0.42f).setDuration(180L).withEndAction { menu.visibility = View.INVISIBLE }.start()
            }
            host.invalidateScene()
        }
    }

    private fun segmentedDemo(): View = opticalBackdrop(92f, "STANDARD     SCIENTIFIC     PROGRAMMER").apply {
        addView(LiquidSegmentedControl(this@GlassPrototypeActivity).apply {
            labels = listOf("Standard", "Scientific", "Programmer")
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58f), Gravity.CENTER).apply { leftMargin = dp(12f); rightMargin = dp(12f) })
    }

    private fun sliderDemo(): View = opticalBackdrop(92f, "0        25        50        75        100").apply {
        addView(LiquidSlider(this@GlassPrototypeActivity), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64f), Gravity.CENTER).apply { leftMargin = dp(10f); rightMargin = dp(10f) })
    }

    private fun keypadDemo(): View = opticalBackdrop(198f, "12.5 + 8 × 4              44.5").apply {
        val grid = LinearLayout(this@GlassPrototypeActivity).apply { orientation = LinearLayout.VERTICAL }
        listOf(
            listOf("7", "8", "9", "÷"),
            listOf("4", "5", "6", "×"),
            listOf("1", "2", "3", "="),
        ).forEachIndexed { rowIndex, row ->
            val line = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEachIndexed { colIndex, text ->
                val button = LiquidGlassButton(context).apply {
                    label = text
                    variant = when {
                        text == "=" -> GlassMaterialRenderer.Variant.TINTED_ACTION
                        colIndex == 3 -> GlassMaterialRenderer.Variant.REGULAR_CLEAR
                        else -> GlassMaterialRenderer.Variant.LIGHTWEIGHT
                    }
                }
                line.addView(button, LinearLayout.LayoutParams(0, dp(52f), 1f).apply { setMargins(dp(3f), dp(3f), dp(3f), dp(3f)) })
            }
            grid.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58f)))
        }
        addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(174f), Gravity.BOTTOM).apply { leftMargin = dp(6f); rightMargin = dp(6f); bottomMargin = dp(4f) })
    }
}
