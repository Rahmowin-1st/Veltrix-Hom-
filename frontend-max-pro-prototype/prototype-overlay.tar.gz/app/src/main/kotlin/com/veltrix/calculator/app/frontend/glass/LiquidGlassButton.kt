package com.veltrix.calculator.app.frontend.glass

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

class LiquidGlassButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    var label: String = ""
        set(value) { field = value; contentDescription = value; invalidate() }
    var variant: GlassMaterialRenderer.Variant = GlassMaterialRenderer.Variant.REGULAR_CLEAR
    var tintColor: Int = Color.rgb(225, 158, 48)
    var reducedTransparency: Boolean = false
    var hapticsEnabled: Boolean = true
    var glyph: Glyph = Glyph.NONE
        set(value) { field = value; invalidate() }

    enum class Glyph { NONE, BACK, GRID, LIBRARY, BRAIN, SWAP, CLOSE }

    private val renderer = GlassMaterialRenderer(this)
    private val bounds = RectF()
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(28, 30, 32)
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans", Typeface.NORMAL)
    }
    private val normalTypeface = Typeface.create("sans", Typeface.NORMAL)
    private val boldTypeface = Typeface.create("sans", Typeface.BOLD)
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(28, 30, 32)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private var touchX = 0f
    private var touchY = 0f
    private var down = false
    private val pressSpring = SpringFloat(0f, 460f, 42f) {
        scaleX = 1f - it * 0.018f
        scaleY = 1f - it * 0.030f
        invalidate()
    }

    init {
        isClickable = true
        isFocusable = true
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val host = findHost()
        if (host?.isCapturingScene == true) return
        bounds.set(0f, 0f, width.toFloat(), height.toFloat())
        val radius = min(width, height) * 0.46f
        renderer.draw(canvas, bounds, radius, variant, tintColor, pressSpring.value, touchX, touchY, reducedTransparency)
        drawForeground(canvas)
    }

    private fun drawForeground(canvas: Canvas) {
        val density = resources.displayMetrics.density
        if (glyph != Glyph.NONE) {
            iconPaint.strokeWidth = 2.1f * density
            val cx = width * 0.5f
            val cy = height * 0.5f
            val s = min(width, height) * 0.22f
            when (glyph) {
                Glyph.BACK -> {
                    canvas.drawLine(cx + s * 0.45f, cy - s, cx - s * 0.55f, cy, iconPaint)
                    canvas.drawLine(cx - s * 0.55f, cy, cx + s * 0.45f, cy + s, iconPaint)
                }
                Glyph.CLOSE -> {
                    canvas.drawLine(cx - s, cy - s, cx + s, cy + s, iconPaint)
                    canvas.drawLine(cx + s, cy - s, cx - s, cy + s, iconPaint)
                }
                Glyph.SWAP -> {
                    canvas.drawLine(cx - s, cy - s * 0.45f, cx + s * 0.75f, cy - s * 0.45f, iconPaint)
                    canvas.drawLine(cx + s * 0.75f, cy - s * 0.45f, cx + s * 0.30f, cy - s * 0.9f, iconPaint)
                    canvas.drawLine(cx + s, cy + s * 0.45f, cx - s * 0.75f, cy + s * 0.45f, iconPaint)
                    canvas.drawLine(cx - s * 0.75f, cy + s * 0.45f, cx - s * 0.30f, cy + s * 0.9f, iconPaint)
                }
                Glyph.GRID -> {
                    val r = s * 0.28f
                    val o = 0.55f * s
                    canvas.drawRoundRect(cx - o - r, cy - o - r, cx - o + r, cy - o + r, r * 0.45f, r * 0.45f, iconPaint)
                    canvas.drawRoundRect(cx + o - r, cy - o - r, cx + o + r, cy - o + r, r * 0.45f, r * 0.45f, iconPaint)
                    canvas.drawRoundRect(cx - o - r, cy + o - r, cx - o + r, cy + o + r, r * 0.45f, r * 0.45f, iconPaint)
                    canvas.drawRoundRect(cx + o - r, cy + o - r, cx + o + r, cy + o + r, r * 0.45f, r * 0.45f, iconPaint)
                }
                Glyph.LIBRARY -> {
                    canvas.drawLine(cx - s * 0.8f, cy - s, cx - s * 0.8f, cy + s, iconPaint)
                    canvas.drawLine(cx, cy - s, cx, cy + s, iconPaint)
                    canvas.drawLine(cx + s * 0.8f, cy - s, cx + s * 0.8f, cy + s, iconPaint)
                }
                Glyph.BRAIN -> {
                    for (i in -1..1) canvas.drawLine(cx - s, cy + i * s * 0.65f, cx + s, cy + i * s * 0.65f, iconPaint)
                }
                Glyph.NONE -> Unit
            }
        } else if (label.isNotBlank()) {
            textPaint.textSize = min(height * 0.34f, 18f * density)
            textPaint.typeface = if (variant == GlassMaterialRenderer.Variant.TINTED_ACTION) boldTypeface else normalTypeface
            val baseline = height * 0.5f - (textPaint.ascent() + textPaint.descent()) * 0.5f
            canvas.drawText(label, width * 0.5f, baseline, textPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabled) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                down = true
                touchX = event.x; touchY = event.y
                pressSpring.snapTo(0.34f)
                pressSpring.animateTo(1f)
                if (hapticsEnabled) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                isPressed = true
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                touchX = event.x; touchY = event.y
                val inside = event.x >= 0 && event.x <= width && event.y >= 0 && event.y <= height
                if (!inside && down) pressSpring.animateTo(0.35f)
                else if (inside && down) pressSpring.animateTo(1f)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                val inside = event.x >= 0 && event.x <= width && event.y >= 0 && event.y <= height
                isPressed = false
                pressSpring.animateTo(0f)
                parent?.requestDisallowInterceptTouchEvent(false)
                if (down && inside) performClick()
                down = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                down = false
                isPressed = false
                pressSpring.animateTo(0f)
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun findHost(): GlassSceneHost? {
        var p = parent
        while (p != null) {
            if (p is GlassSceneHost) return p
            p = p.parent
        }
        return null
    }
}
