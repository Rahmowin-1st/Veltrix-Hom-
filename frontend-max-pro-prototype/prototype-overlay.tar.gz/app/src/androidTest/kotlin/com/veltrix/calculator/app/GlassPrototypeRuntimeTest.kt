package com.veltrix.calculator.app

import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.veltrix.calculator.app.frontend.prototype.GlassPrototypeActivity
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class GlassPrototypeRuntimeTest {
    @Test fun prototypeLabLaunchesAndHasEightSections() {
        ActivityScenario.launch(GlassPrototypeActivity::class.java).use { scenario ->
            scenario.onActivity { activity ->
                val root = activity.window.decorView
                assertTrue(root.isShown)
                assertTrue(root.contentDescription == null || root.contentDescription.toString().isNotBlank())
            }
        }
    }
}
