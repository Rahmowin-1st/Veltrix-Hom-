# Veltrix Frontend MAX PRO — Phase 1 Architecture Plan

## Perceptual target

The supplied material is a digital optical layer, not glassmorphism. Its identity comes from transmission, lensing/refraction, edge light concentration, apparent thickness, environment response and touch-driven deformation. Motion and material are one system; resting state is quiet and interaction energizes the material. Glass is primarily a control/navigation layer above calm content, with selective tint and no glass-on-glass stacking.

## Why the rejected frontend failed

The rejected renderer created appearance from self-contained gradients/rims/glow. It did not sample meaningful app content, so it could not visibly bend or lens what was underneath. The frontend also rebuilt entire screen trees during ordinary navigation, creating unnecessary allocation/layout/render pressure and state discontinuity.

## New Android render architecture

`GlassSceneHost` owns a controlled reusable snapshot of the real child content. During snapshot capture, glass controls omit themselves, so high-value optical controls can sample the actual content layer rather than recursively sampling glass. API 33+ controls use a cached AGSL `RuntimeShader` with a reusable `BitmapShader` scene input. Per-frame interaction updates uniforms only: geometry, scene origin, touch location, press energy, material thickness, clarity and tint. The shader performs coordinate displacement, restrained chromatic separation, adaptive tinting, directional edge concentration and touch-origin light response.

The scene snapshot is *not* copied every animation frame. It is refreshed on size/layout/content-state changes. Glass-only motion uses the existing scene input. Dense keypad controls use a lighter material family. Older APIs and reduced-transparency mode use an honest high-contrast translucent fallback and are never described as full refraction.

## Performance model

- RuntimeShader compiled once per renderer and then reused.
- Scene bitmap and Canvas reused by `GlassSceneHost`.
- No Paint/Path/gradient allocation in hot glass draw loops.
- Interaction changes shader uniforms and transform properties, not layout.
- Scene capture is invalidation-driven, not continuous.
- Expensive optical material is reserved for high-value controls; dense controls use lightweight material.
- Heavy product systems remain lazy; Standard Calculator first frame gets priority.
- Graph renderer will cache paths/matrices/data and reduce label work during direct manipulation.

## Motion model

Direct manipulation is 1:1. Release preserves velocity into an interruptible spring/decay. Segmented control uses one continuous lens object. Slider lens expands on touch, follows the finger, deforms directionally, and settles without decorative overshoot. Menu/popover geometry grows from the triggering control. No idle motion.

## Navigation model

The shipping frontend will keep one persistent root/shell. Standard Calculator is the default root. Converters, Library and Main Brain are top-level systems with no bottom navigation. Main Brain uses a spatial, reversible transition and an interior-origin gesture that does not steal Android back edges. Predictive back uses Android-supported back APIs.
